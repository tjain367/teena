<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Task extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->config->load("jwt");

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: *");
        header("Access-Control-Allow-Headers: *");

        if ( "OPTIONS" === $_SERVER['REQUEST_METHOD'] ) {
            die();
        }
    }


    public function create() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['user_id']) && !empty($request['task'])) {

                date_default_timezone_set('Asia/kolkata');

                $details['created_by']  = $request['user_id'];
                $details['project_id']  = $request['project_id'];
                $details['user_id']     = $request['user_id'];
                $details['task']        = $request['task'];
                $details['date']        = date('Y-m-d');
            
            	if(!empty($request['list_id'])) {
                	$details['list_id']  = $request['list_id'];
                }

                $result = $this->api_model->insert_common('tasks',$details);
                
                $response = array('error' => 'Task added successfully', 'status' => 200, 'list_id' => $request['list_id']);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }
    





    public function addsubtask() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['user_id']) && !empty($request['subtask'])) {

                date_default_timezone_set('Asia/kolkata');

                $details['created_by']  = $request['user_id'];

                if(!empty($request['project_id'])) {
                    $details['project_id']  = $request['project_id'];
                }
                    
                $details['user_id']     = $request['user_id'];
                $details['task_id']     = $request['task_id'];
                $details['subtask']     = $request['subtask'];

                $result = $this->api_model->insert_common('subtasks',$details);
                
                $response = array('error' => 'Subask added successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



	public function fetchtaskbylistid() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['list_id'])) {
                $datas = $tasks_arr = $completed_tasks_arr = array();

                $tasks = $this->api_model->fetchtaskbylist($request['user_id'], $request['project_id'], $request['list_id']);

                if(!empty($tasks)) {
                    foreach($tasks as $value) {

                        $subtask = $this->api_model->list_subtask_bytaskid('subtasks','task_id',$value['id']);
                        $import = '0';
                        $imp = explode(",",$value['important']);

                        if(in_array($request['user_id'], $imp)){
                            $import = '1';
                        }   

                        $arr = explode(",",$value['status']);

                        if(in_array($request['user_id'], $arr)) {
                            array_push($completed_tasks_arr, array('id' => $value['id'], 'task' => $value['task'], 'subtask' => $subtask, 'important' => $import));
                        }else{
                            array_push($tasks_arr, array('id' => $value['id'], 'task' => $value['task'], 'subtask' => $subtask, 'important' => $import));
                        }
                    }
                }    

                $datas['task'] = $tasks_arr;
                $datas['completed_task'] = $completed_tasks_arr;

                $response = array('error' => 'Task found', 'status' => 200, 'data' => $datas);
            }else{
                $response = array('error' => 'Please Select List', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }

    

    // fetch all today tasks by project
    public function fetchtodaytaskbyprojectid() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            $datas = $tasks_arr = $completed_tasks_arr = array();

            date_default_timezone_set('Asia/Kolkata');
            $date = date('Y-m-d');

            if(!empty($request['project_id'])) {
                $tasks = $this->api_model->fetchprojecttaskapi($request['user_id'], $request['project_id'], $date);
            }else{
                $tasks = $this->api_model->fetchtaskapi($request['user_id'], $date);
            }    

            if(!empty($tasks)) {
                foreach($tasks as $value) {

                    $subtask = $this->api_model->list_subtask_bytaskid('subtasks','task_id',$value['id']);
                    $import = '0';
                    $project_id = $project_name = "";
                    $imp = explode(",",$value['important']);

                    if(in_array($request['user_id'], $imp)){
                        $import = '1';
                    }   

                    $arr = explode(",",$value['status']);
                
                	if($value['list_id'] == 0) {
                    	$label = "Tasks";
                    }else{
                    	$lab = $this->api_model->list_common_where3('folder_list','id', $value['list_id']);
                    	if(!empty($lab[0]['list_name'])) {
                        	$label = $lab[0]['list_name'];
                        
                        	$fold = $this->api_model->list_common_where3('generic_folder','id', $lab[0]['folder_id']);
                        	if(!empty($fold[0]['folder_name'])) {
                            	$label = $fold[0]['folder_name']." >> ".$label;
                            }
                        }
                    }

                    if(!empty($value['project_id'])) {
                        $project_id = $value['project_id'];
                        $project_name = $value['project_name'];
                    }

                    if(in_array($request['user_id'], $arr)) {
                        array_push($completed_tasks_arr, array('id' => $value['id'], 'task' => $value['task'], 'project_id' => $project_id, 'project_name' => $project_name, 'subtask' => $subtask, 'important' => $import, 'label' => $label));
                    }else{
                        array_push($tasks_arr, array('id' => $value['id'], 'task' => $value['task'], 'project_id' => $project_id, 'project_name' => $project_name, 'subtask' => $subtask, 'important' => $import, 'label' => $label));
                    }
                }
            }    

            $datas['task'] = $tasks_arr;
            $datas['completed_task'] = $completed_tasks_arr;

            $response = array('error' => 'Task found', 'status' => 200, 'data' => $datas);

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }




    // fetch all tasks by project
    public function fetchtaskbyprojectid() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            $datas = $tasks_arr = $completed_tasks_arr = array();

            if(!empty($request['project_id'])) {
                $tasks = $this->api_model->fetchprojecttaskapi($request['user_id'], $request['project_id']);
            }else{
                $tasks = $this->api_model->fetchtaskapi($request['user_id']);
            }    

            if(!empty($tasks)) {
                foreach($tasks as $value) {
                    $subtask = $this->api_model->list_subtask_bytaskid('subtasks','task_id',$value['id']);
                    $import = '0';
                    $project_id = $project_name = "";
                    $imp = explode(",",$value['important']);

                    if(in_array($request['user_id'], $imp)){
                        $import = '1';
                    }   

                    $arr = explode(",",$value['status']);
                
                	if($value['list_id'] == 0) {
                    	$label = "Tasks";
                    }else{
                    	$lab = $this->api_model->list_common_where3('folder_list','id', $value['list_id']);
                    	if(!empty($lab[0]['list_name'])) {
                        	$label = $lab[0]['list_name'];
                        
                        	$fold = $this->api_model->list_common_where3('generic_folder','id', $lab[0]['folder_id']);
                        	if(!empty($fold[0]['folder_name'])) {
                            	$label = $fold[0]['folder_name']." >> ".$label;
                            }
                        }
                    }

                    if(!empty($value['project_id'])) {
                        $project_id = $value['project_id'];
                        $project_name = $value['project_name'];
                    }

                    if(in_array($request['user_id'], $arr)) {
                        array_push($completed_tasks_arr, array('id' => $value['id'], 'project_id' => $project_id, 'project_name' => $project_name, 'task' => $value['task'], 'subtask' => $subtask, 'important' => $import, 'label' => $label));
                    }else{
                        array_push($tasks_arr, array('id' => $value['id'], 'project_id' => $project_id, 'project_name' => $project_name, 'task' => $value['task'], 'subtask' => $subtask, 'important' => $import, 'label' => $label));
                    }
                }
            }       

            $datas['task'] = $tasks_arr;
            $datas['completed_task'] = $completed_tasks_arr;

            $response = array('error' => 'Task found', 'status' => 200, 'data' => $datas);
        

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



    // fetch all task assigned to me 
    public function fetchtaskassignedtome() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            $datas = $tasks_arr = $completed_tasks_arr = array();

            if(!empty($request['project_id'])) {
                $tasks = $this->api_model->fetchtaskapi2($request['project_id']);
            }else{
                $tasks = $this->api_model->fetchtaskapi2();
            }  

            if(!empty($tasks)) {
                foreach($tasks as $value) {
                    $created_by = "";

                    $subtask = $this->api_model->list_subtask_bytaskid('subtasks','task_id',$value['id']);
                    $import = '0';
                    $project_id = $project_name = "";
                    $imp = explode(",",$value['important']);

                    if(in_array($request['user_id'], $imp)){
                        $import = '1';
                    }   

                    $arr = explode(",",$value['status']);
                
                	if($value['list_id'] == 0) {
                    	$label = "Tasks";
                    }else{
                    	$lab = $this->api_model->list_common_where3('folder_list','id', $value['list_id']);
                    	if(!empty($lab[0]['list_name'])) {
                        	$label = $lab[0]['list_name'];
                        
                        	$fold = $this->api_model->list_common_where3('generic_folder','id', $lab[0]['folder_id']);
                        	if(!empty($fold[0]['folder_name'])) {
                            	$label = $fold[0]['folder_name']." >> ".$label;
                            }
                        }
                    }
                    
                    if(!empty($value['project_id'])) {
                        $project_id = $value['project_id'];
                        $project_name = $value['project_name'];
                    }

                    if($value['assigned_to'] == "All") {
                        if(in_array($request['user_id'], $arr)) {
                            array_push($completed_tasks_arr, array('id' => $value['id'], 'project_id' => $project_id, 'project_name' => $project_name, 'task' => $value['task'], 'subtask' => $subtask, 'important' => $import, 'label' => $label));
                        }else{
                            array_push($tasks_arr, array('id' => $value['id'], 'project_id' => $project_id, 'project_name' => $project_name, 'task' => $value['task'], 'subtask' => $subtask, 'important' => $import, 'label' => $label));
                        }
                    }else{
                        $assignarr = explode(",",$value['assigned_to']);

                        if(in_array($request['user_id'], $assignarr)) {
                            if(in_array($request['user_id'], $arr)) {
                                array_push($completed_tasks_arr, array('id' => $value['id'], 'project_id' => $project_id, 'project_name' => $project_name, 'task' => $value['task'], 'subtask' => $subtask, 'important' => $import, 'label' => $label));
                            }else{
                                array_push($tasks_arr, array('id' => $value['id'], 'project_id' => $project_id, 'project_name' => $project_name, 'task' => $value['task'], 'subtask' => $subtask, 'important' => $import, 'label' => $label));
                            }
                        }    
                    }
                    
                }
            }    

            $datas['task'] = $tasks_arr;
            $datas['completed_task'] = $completed_tasks_arr;

            $response = array('error' => 'Task found', 'status' => 200, 'data' => $datas);
       

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }


    

    // fetch all tasks by project
    public function fetchimportantasks() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            $datas = $tasks_arr = $completed_tasks_arr = array();

            if(!empty($request['project_id'])) {
                $tasks = $this->api_model->fetchtaskapi2($request['project_id']);
            }else{
                $tasks = $this->api_model->fetchtaskapi2();
            }    
            
            if(!empty($tasks)) {
                foreach($tasks as $value) {
                    $subtask = $this->api_model->list_subtask_bytaskid('subtasks','task_id',$value['id']);
                    $import = '0';
                    $project_id = $project_name = "";
                    $imp = explode(",",$value['important']);

                    if(in_array($request['user_id'], $imp)){
                        $import = '1';
                    }   

                    $arr = explode(",",$value['status']);
                
                	if($value['list_id'] == 0) {
                    	$label = "Tasks";
                    }else{
                    	$lab = $this->api_model->list_common_where3('folder_list','id', $value['list_id']);
                    	if(!empty($lab[0]['list_name'])) {
                        	$label = $lab[0]['list_name'];
                        
                        	$fold = $this->api_model->list_common_where3('generic_folder','id', $lab[0]['folder_id']);
                        	if(!empty($fold[0]['folder_name'])) {
                            	$label = $fold[0]['folder_name']." >> ".$label;
                            }
                        }
                    }

                    if(!empty($value['project_id'])) {
                        $project_id = $value['project_id'];
                        $project_name = $value['project_name'];
                    }

                    if(in_array($request['user_id'], $arr) && ($import == '1')) {
                        array_push($completed_tasks_arr, array('id' => $value['id'], 'project_id' => $project_id, 'project_name' => $project_name, 'task' => $value['task'], 'subtask' => $subtask, 'important' => $import, 'label' => $label));
                    }else if($import == '1'){
                        array_push($tasks_arr, array('id' => $value['id'], 'project_id' => $project_id, 'project_name' => $project_name, 'task' => $value['task'], 'subtask' => $subtask, 'important' => $import, 'label' => $label));
                    }
                }
            }       

            $datas['task'] = $tasks_arr;
            $datas['completed_task'] = $completed_tasks_arr;

            $response = array('error' => 'Task found', 'status' => 200, 'data' => $datas);
        

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }




    // important task
    public function updateimportantstatus() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['task_id']) && !empty($request['user_id'])) {
                
                $exist = $this->api_model->list_common_where3('tasks', 'id', $request['task_id']);
                
                if(!empty($exist)) {

                    if(empty($exist[0]['important'])) {
                        $savedata['important'] = $request['user_id'];
                        $err = 'Added in Important';
                        $up = '1';
                    }else{

                        $arr = explode(",",$exist[0]['important']);

                        if(in_array($request['user_id'], $arr)) {

                            $val = array($request['user_id']);
                            $res = array_diff($arr, $val);
                            $savedata['important'] = implode(",", $res);

                            $err = 'Removed from Important';
                            $up = '0';
                        }else{
                            $savedata['important'] = $exist[0]['important'].",".$request['user_id'];
                            $err = 'Added in Important';
                            $up = '1';
                        }
                    }
                    
                    $this->api_model->update_common('tasks', $savedata, 'id', $request['task_id']);
                    $response = array('error' => $err, 'status' => 200, 'value' => $up);
                }else{
                    $response = array('error' => 'Invalid Task Id', 'status' => 400);
                }
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



    // add my day task
    public function updatecompletedstatus() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['task_id']) && !empty($request['user_id'])) {
                
                $exist = $this->api_model->list_common_where3('tasks', 'id', $request['task_id']);
                
                if(!empty($exist)) {

                    if(empty($exist[0]['status'])) {
                        $savedata['status'] = $request['user_id'];
                        $err = 'Completed';
                    }else{

                        $arr = explode(",",$exist[0]['status']);

                        if(in_array($request['user_id'], $arr)) {

                            $val = array($request['user_id']);
                            $res = array_diff($arr, $val);
                            $savedata['status'] = implode(",", $res);

                            $err = 'Removed from completed';
                        }else{
                            $savedata['status'] = $exist[0]['status'].",".$request['user_id'];
                            $err = 'Completed';
                        }
                    }
                    
                    $this->api_model->update_common('tasks', $savedata, 'id', $request['task_id']);
                    $response = array('error' => $err, 'status' => 200);
                }else{
                    $response = array('error' => 'Invalid Task Id', 'status' => 400);
                }
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }


    // add my day task
    public function updatemydaystatus() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['task_id']) && !empty($request['user_id'])) {
                
                $exist = $this->api_model->searchdata('tasks_myday', $request['task_id'], $request['user_id']);
                
                if(empty($exist)) {
                    date_default_timezone_set('Asia/Kolkata');

                    $data['task_id'] = $request['task_id'];
                    $data['user_id'] = $request['user_id'];
                    $data['myday_date'] = date('Y-m-d');
                    
                    $this->api_model->insert_common('tasks_myday',$data);
                    $response = array('error' => 'Added to My Day', 'status' => 200);
                }else{

                    $this->api_model->delete_common('tasks_myday','id',$exist->id);
                    $response = array('error' => 'Removed from My Day', 'status' => 200);
                }
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }




    // add my day task
    public function addreminder() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['task_id']) && !empty($request['user_id'])) {
                
                $exist = $this->api_model->searchdata('task_reminder', $request['task_id'], $request['user_id']);
                
                if(empty($exist)) {
                    $data['task_id'] = $request['task_id'];
                    $data['user_id'] = $request['user_id'];
                    $data['reminder_at'] = $request['remind_me'];
                    
                    $this->api_model->insert_common('task_reminder',$data);
                    $response = array('error' => 'Reminder set', 'status' => 200, 'value' => '1', 'remind_me' => $request['remind_me']);
                }else{

                    $data['reminder_at'] = $request['remind_me'];

                    $this->api_model->update_common('task_reminder',$data, 'id',$exist->id);
                    $response = array('error' => 'Reminder updated', 'status' => 200, 'value' => '0', 'remind_me' => $request['remind_me']);
                }
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



    // add my day task
    public function removereminder() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['task_id']) && !empty($request['user_id'])) {
                
                $exist = $this->api_model->searchdata('task_reminder', $request['task_id'], $request['user_id']);
                
                if(!empty($exist)) {                    
                    $this->api_model->delete_common('task_reminder','id', $exist->id);
                    $response = array('error' => 'Reminder unset', 'status' => 200);
                }else{
                    $response = array('error' => 'Something went wrong! Try Again', 'status' => 400);
                }
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



    // add my day task
    public function addduedate() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['task_id']) && !empty($request['user_id'])) {
                
                $exist = $this->api_model->searchdata('task_duedate', $request['task_id'], $request['user_id']);
                
                if(empty($exist)) {
                    $data['task_id'] = $request['task_id'];
                    $data['user_id'] = $request['user_id'];
                    $data['due_date'] = $request['due_date'];
                    
                    $this->api_model->insert_common('task_duedate',$data);
                    $response = array('error' => 'Due Date set', 'status' => 200, 'value' => '1', 'due_date' => $request['due_date']);
                }else{

                    $data['due_date'] = $request['due_date'];
                    $this->api_model->update_common('task_duedate',$data, 'id',$exist->id);
                    $response = array('error' => 'Due Date updated', 'status' => 200, 'value' => '0', 'due_date' => $request['due_date']);
                }
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



    // add my day task
    public function removeduedate() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['task_id']) && !empty($request['user_id'])) {
                
                $exist = $this->api_model->searchdata('task_duedate', $request['task_id'], $request['user_id']);
                
                if(!empty($exist)) {                    
                    $this->api_model->delete_common('task_duedate','id', $exist->id);
                    $response = array('error' => 'Due Date unset', 'status' => 200);
                }else{
                    $response = array('error' => 'Something went wrong! Try Again', 'status' => 400);
                }
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }




    // add my day task
    public function addrepeatdate() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['task_id']) && !empty($request['user_id'])) {
                
                $exist = $this->api_model->searchdata('task_repeat', $request['task_id'], $request['user_id']);
                
                if(empty($exist)) {
                    $data['task_id'] = $request['task_id'];
                    $data['user_id'] = $request['user_id'];
                    $data['repeat_date'] = $request['repeat_date'];
                    
                    $this->api_model->insert_common('task_repeat',$data);
                    $response = array('error' => 'Repeat Date set', 'status' => 200, 'value' => '1', 'repeat_date' => $request['repeat_date']);
                }else{

                    $data['repeat_date'] = $request['repeat_date'];
                    $this->api_model->update_common('task_repeat',$data, 'id',$exist->id);
                    $response = array('error' => 'Repeat Date updated', 'status' => 200, 'value' => '0', 'repeat_date' => $request['repeat_date']);
                }
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



    // add my day task
    public function removerepeatdate() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['task_id']) && !empty($request['user_id'])) {
                
                $exist = $this->api_model->searchdata('task_repeat', $request['task_id'], $request['user_id']);
                
                if(!empty($exist)) {                    
                    $this->api_model->delete_common('task_repeat','id', $exist->id);
                    $response = array('error' => 'Repeat Date unset', 'status' => 200);
                }else{
                    $response = array('error' => 'Something went wrong! Try Again', 'status' => 400);
                }
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



    public function addnote() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['task_id']) && !empty($request['user_id'])) {
                
                $exist = $this->api_model->searchdata('task_note', $request['task_id'], $request['user_id']);
                
                if(empty($exist)) {
                    $data['task_id'] = $request['task_id'];
                    $data['user_id'] = $request['user_id'];
                    $data['note']    = $request['note'];
                    
                    $this->api_model->insert_common('task_note',$data);
                    $response = array('error' => 'Note saved', 'status' => 200, 'value' => '1');
                }else{
                    $data['note'] = $request['note'];
                    $this->api_model->update_common('task_note',$data, 'id',$exist->id);
                    $response = array('error' => 'Note updated', 'status' => 200, 'value' => '0');
                }
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }

    

    public function assignuser() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['task_id']) && !empty($request['user_id'])) {
                
                $data['assigned_by'] = $request['user_id'];
                $data['assigned_to'] = $request['assigned_to'];
                
                $this->api_model->update_common('tasks',$data,'id',$request['task_id']);
                $response = array('error' => 'Task Assigned', 'status' => 200);
                
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }


    public function uploadfile() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {
        
            $task_id = $this->input->post('task_id');
            $user_id = $this->input->post('user_id');

            if(!empty($task_id) && !empty($user_id)) {
                
                $exist = $this->api_model->searchdata('task_uploadfile', $task_id, $user_id);
                
                $data['task_id'] = $task_id;
                $data['user_id'] = $user_id;

                $rand = rand(1000,9999);
                if(!empty($_FILES['file']['name'])) {
                    $file = $rand.$_FILES['file']['name']; 
                    $data['file'] = "uploads/".basename($file);
                    move_uploaded_file($_FILES['file']['tmp_name'], "uploads/".$file); 
                }
                
                $this->api_model->insert_common('task_uploadfile',$data);

                $response = array('error' => 'File saved', 'status' => 200);

            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



    // add my day task
    public function fetchdetail() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {
            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['task_id']) && !empty($request['user_id'])) {
                
                $file_arr = array();
                $reminder = $due_date = $repeat_date = $task_note = $users = '';
                
                $exist = $this->api_model->searchdata('task_reminder', $request['task_id'], $request['user_id']);
                if(!empty($exist)) {    $reminder = $exist->reminder_at;    }

                $exist2 = $this->api_model->searchdata('task_duedate', $request['task_id'], $request['user_id']);
                if(!empty($exist2)) {    $due_date = $exist2->due_date;    }

                $exist3 = $this->api_model->searchdata('task_repeat', $request['task_id'], $request['user_id']);
                if(!empty($exist3)) {    $repeat_date = $exist3->repeat_date;    }
            
                $exist4 = $this->api_model->searchdata('task_note', $request['task_id'], $request['user_id']);
                if(!empty($exist4)) {    $task_note = $exist4->note;    }
            
                $files = $this->api_model->list_common_where3('task_uploadfile','task_id', $request['task_id']);
                if(!empty($files)) {
                    foreach($files as $values) {
                        array_push($file_arr, array('file' => $values['file'], 'name' => substr($values['file'],16) ));
                    }
                }

            	$taskdata = $this->api_model->list_common_where3('tasks', 'id', $request['task_id']);
                if(!empty($taskdata)) {    $users = $taskdata[0]['assigned_to'];    }
            
                $data = array('reminder' => $reminder, 'due_date' => $due_date, 'repeat_date' => $repeat_date, 'note' => $task_note, 'files' => $file_arr, 'users' => $users);

                $response = array('error' => 'Task Details', 'status' => 200, 'data' => $data);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }


    
    // add my day task
    public function fetchinformationforpopover() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {
            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['task_id']) && !empty($request['user_id'])) {

                $task_details = $this->api_model->taskdetails($request['task_id']);
                $file_arr = array();
            
                $files = $this->api_model->list_common_where3('task_uploadfile','task_id', $request['task_id']);
                if(!empty($files)) {
                    foreach($files as $values) {
                        array_push($file_arr, array('file' => $values['file']));
                    }
                }
            
                $html = "<div class='row'>
                            <div class='col-md-12'>
                                <b>Created By: </b>";
                                $html .= $task_details[0]['name'];
                $html .=    "</div>
                            <div class='col-md-12'>";
            
                                if($task_details[0]['assigned_to'] == 'all') {
                                    $html .= "<b>Assigned To:</b> All";
                                }else{
                                    $html .= "<b>Assigned To:</b> ";
                                
                                    $assign_arr = explode(",",$task_details[0]['assigned_to']);
                                    for($i = 0; $i < count($assign_arr); $i++) {
                                        
                                        $us = $this->api_model->list_common_where3('users','id',$assign_arr[$i]);
                                        if(!empty($us)) {
                                            $html .= $us[0]['name'];

                                            if(count($assign_arr) > ($i + 1)) {
                                                $html .= ", ";
                                            }
                                        } 
                                    } 
                                }

                $html .=    "</div>
                        </div>";
            
                $data = array('popover' => $html);

                $response = array('error' => 'Task Details', 'status' => 200, 'data' => $data);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }




	public function update() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {
            $request = json_decode(file_get_contents('php://input'),1); 
            if(!empty($request['task_id'])) {
                $datas = array(
                    'id' => $request['task_id'],
                    'task' => $request['task_name'],
                   );
             
                $book = $this->api_model->update_common('tasks', $datas,'id',$request['task_id']);
                $response = array('error' => 'task update Successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Something Went Wrong', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    
        echo json_encode($response);
    }


    public function delete() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['task_id'])) {

                $book = $this->api_model->delete_common('tasks', 'id', $request['task_id']);

                $response = array('error' => 'Task deleted Successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Please Select Meeting', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }


    public function fetchtaskdetail() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {
            $request = json_decode(file_get_contents('php://input'),1); 
            if(!empty($request['task_id'])) {  
                $book = $this->api_model->list_common_where3('tasks','id', $request['task_id']);
                $datas['task'] = $book[0]['task'];
                 $response = array('error' => 'task Details Found', 'status' => 200, 'data' => $datas);
            }else{
               $response = array('error' => 'Please task', 'status' => 400);
            }
        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    
            
        echo json_encode($response);               
    }
	


}

?>    