<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Mail extends CI_Controller {

    function __construct() {
        parent::__construct();

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
        header("Access-Control-Allow-Headers: *");

		if ( "OPTIONS" === $_SERVER['REQUEST_METHOD'] ) {
		    die();
		}

        $this->load->library('email');
    }



    public function compose() {

        $res = $this->auth->decode_jwt_token();
            if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 
            $response = array();

            if(!empty($request['user_email'])) {

                $msg = "Mail Saved as Draft";

                if($request['type'] == "sent") {

                    $config = Array(
                        'protocol' => 'mail',
                        'smtp_host' => 'smtp.gmail.com',
                        'smtp_port' => 587, 
                        'smtp_user' => 'vikrant11933@gmail.com',
                        'smtp_pass' => 'pakistankebaaphum',
                        'newline' => '\r\n',
                        'mailtype' => 'html',
                        'charset' => 'utf-8',
                        'wordwrap' => TRUE
                    );

                    $otp = rand(100000,999999);
                    $subject = $request['subject'];
                    $message = $request['message'];
                            
                    $headers = 'MIME-Version: 1.0' . "\r\n";
                    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

                    $this->email->initialize($config);
                    $this->email->from($request['user_email']);
                    $this->email->to($request['receiver_email']);
                    $this->email->subject($subject);
                    $this->email->message($message);
                    $this->email->send();

                    $msg = "Mail Sent";

                }    

                $details['user_id'] = $request['user_id'];
                $details['user_email'] = $request['user_email'];
                $details['subject'] = $request['subject'];
                $details['message'] = $request['message'];
                $details['module'] = $request['type'];

                $result = $this->api_model->insert_common('mailbox', $details);

                if(!empty($result)) {
                    $sent_to['receiver'] = $request['receiver_email'];
                    $sent_to['mailbox_id'] = $result;

                    $this->api_model->insert_common('mailbox_to', $sent_to);
                }

                $response = array('error' => 'Mail Sent', 'status' => 200);

            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }
        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }


        echo json_encode($response);
        exit;
    }


    public function inbox() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {
            $request = json_decode(file_get_contents('php://input'),1); 
            $data = $response = array();

            if(!empty($request['email'])) {

                if(!empty($this->api_model->userexist($request['email']))) {

                    $user_data = $this->api_model->list_common_where3('users','email',$request['email']);

                    if(!empty($user_data)) {

                        if(!empty($user_data[0]['gemail'])) {
                            $email = base64_decode($user_data[0]['gemail']);
                        }else{
                            $email = "test49676@gmail.com";
                        }

                        if(!empty($user_data[0]['gpassword'])) {
                            $password = base64_decode($user_data[0]['gpassword']);
                        }else{
                            $password = "test49676@gmail.com";
                        }

                        // $email = "test49676@gmail.com";
                        // $password = "1!testmailT";


                        $mail_handle = imap_open("{imap.gmail.com:993/ssl}", $email, $password);
                        
                        if(!empty($mail_handle)) {
                            $headers = imap_headers($mail_handle);
                            $last = imap_num_msg($mail_handle); 

                            for($i = $last; $i > 0; $i--) {
                                $single_mail = imap_header($mail_handle, $i);

                                array_push($data, array('id' => $i, 'date' => $single_mail->date, 'subject' => $single_mail->subject, 'from' => $single_mail->from[0]->personal));

                                $response = array('error' => 'Mail Found', 'status' => 200, 'data' => $data);
                            }
                        }else{
                            $response = array('error' => 'Connection not establish

                                ed', 'status' => 400);
                        }    
                    }else{
                        $response = array('error' => 'Gmail Details not found', 'status' => 400);
                    }    
                }else{
                    $response = array('error' => 'Email Address not registered', 'status' => 400);
                }   
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }
        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    


        echo json_encode($response);
        exit;
    }





    public function sentbox() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {
            $request = json_decode(file_get_contents('php://input'),1); 
            $data = $response = array();

            if(!empty($request['id'])) {

                $getdata = $this->api_model->getsentmailbox($request['id']);

                if(!empty($getdata)) {
                    foreach($getdata as $value) {
                        array_push($data, array('id' => $value['id'], 'timestamp' => $value['timestamp'], 'sender_email' => $value['user_email'], 'subject' => $value['subject'], 'message' => $value['message'], 'reciever_email' => $value['receiver']));
                    }
                }    

                $response = array('error' => 'Mail Found', 'status' => 200, 'data' => $data);

            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }
        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
        exit;
    }



    public function draftbox() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {
            $request = json_decode(file_get_contents('php://input'),1); 
            $data = $response = array();

            if(!empty($request['id'])) {

                $getdata = $this->api_model->getdraftmailbox($request['id']);

                if(!empty($getdata)) {
                    foreach($getdata as $value) {
                        array_push($data, array('id' => $value['id'], 'timestamp' => $value['timestamp'], 'sender_email' => $value['user_email'], 'subject' => $value['subject'], 'message' => $value['message'], 'reciever_email' => $value['receiver']));
                    }
                }    

                $response = array('error' => 'Mail Found', 'status' => 200, 'data' => $data);

            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }
        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
        exit;
    }



    public function sentsinglemail() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {
            $request = json_decode(file_get_contents('php://input'),1); 
            $data = $response = array();

            if(!empty($request['id'])) {

                $getdata = $this->api_model->getsentsinglemailbox($request['id']);
                
                if(!empty($getdata)) {
                    $data['timestamp'] = $getdata[0]['timestamp'];  
                    $data['sender_email'] = $getdata[0]['user_email']; 
                    $data['subject'] = $getdata[0]['subject']; 
                    $data['message'] = $getdata[0]['message']; 
                    $data['reciever_email'] = $getdata[0]['receiver']; 
                }    

                $response = array('error' => 'Mail Details Found', 'status' => 200, 'data' => $data);

            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }
        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
        exit;
    }



    public function fullmail() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {
            $request = json_decode(file_get_contents('php://input'),1); 
            $data = $response = array();

            if(!empty($request['email'])) {

                if(!empty($this->api_model->userexist($request['email']))) {

                    $user_data = $this->api_model->list_common_where3('users','email',$request['email']);

                    if(!empty($user_data)) {

                        if(!empty($user_data[0]['gemail'])) {
                            $email = base64_decode($user_data[0]['gemail']);
                        }else{
                            $email = "test49676@gmail.com";
                        }

                        if(!empty($user_data[0]['gpassword'])) {
                            $password = base64_decode($user_data[0]['gpassword']);
                        }else{
                            $password = "test49676@gmail.com";
                        }

                        $mail_handle = imap_open("{imap.gmail.com:993/ssl}", 'test49676@gmail.com', '1!testmailT');

                        $data['head'] = imap_header($mail_handle, $request['number']);
                        $single_mail_body = imap_body($mail_handle, $request['number']);

                        $exp = explode("Content-Transfer-Encoding: quoted-printable",$single_mail_body);
                        $dataexp = $exp[1];

                        $data['body'] = quoted_printable_decode($dataexp); 

                        $response = array('error' => 'Mail Found', 'status' => 200, 'data' => $data);

                    }else{
                        $response = array('error' => 'Gmail Details not Found', 'status' => 400);
                    }    

                }else{
                    $response = array('error' => 'Email Address not registered', 'status' => 400);
                }   
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }
        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);  
        }    

        echo json_encode($response);
        exit;
    }







    public function addcredentials() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['user_id']) && !empty($request['email']) && !empty($request['password'])) {

                date_default_timezone_set('Asia/kolkata');

                $user_id     = $request['user_id'];
                $details['gemail']      = base64_encode($request['email']);
                $details['gpassword']   = base64_encode($request['password']);

                $result = $this->api_model->update_common('users',$details, 'id',$user_id);
                
                $response = array('error' => 'Credentials added successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



    public function jwt_token($data) {
        $jwt = new JWT();
        $jwtSecretKey = $this->config->item('jwt_key');

        $token = $jwt->encode($data,$jwtSecretKey,'HS256');
        return $token;
    }





}

?>
