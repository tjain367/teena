<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Bookmark extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->config->load("jwt");

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: *");
        header("Access-Control-Allow-Headers: *");

        if ( "OPTIONS" === $_SERVER['REQUEST_METHOD'] ) {
            die();
        }
    }


    public function create() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['user_id']) && !empty($request['title']) && !empty($request['project_id'])) {

                date_default_timezone_set('Asia/kolkata');

                $details['user_id']     = $request['user_id'];
                $details['project_id']  = $request['project_id'];
                $details['web_url']     = $request['web_url'];
                $details['title']       = $request['title'];
                $details['description'] = $request['description'];  

                $result = $this->api_model->insert_common('bookmark',$details);
                
                $response = array('error' => 'Bookmark added successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }
    



    // fetch all today tasks by project
    public function fetchall() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['project_id'])) {
                $datas = $tasks_arr = array();

                $book = $this->api_model->list_common_where3('bookmark', 'project_id', $request['project_id']);

                if(!empty($book)) {
                    foreach($book as $value) {
                        array_push($datas, array('id' => $value['id'], 'title' => $value['title'], 'description' => $value['description'], 'web_url' => $value['web_url']));
                    }
                }    

                $response = array('error' => 'Bookmarks found', 'status' => 200, 'data' => $datas);
            }else{
                $response = array('error' => 'Please Select Project', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



    public function delete() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['bookmark_id'])) {

                $book = $this->api_model->delete_common('bookmark', 'id', $request['bookmark_id']);

                $response = array('error' => 'Bookmarks deleted Successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Please Select Bookmark', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



	public function update() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {
            $request = json_decode(file_get_contents('php://input'),1); 
            if(!empty($request['bookmark_id'])) {
                $datas = array(
                    'id' => $request['bookmark_id'],
                    'title' => $request['title'],
                    'web_url' => $request['web_url'],
                    'description' => $request['description'],
                   );
                $book = $this->api_model->update_common('bookmark', $datas, 'id',$request['bookmark_id']);
                $response = array('error' => 'Bookmarks update Successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Something Went Wrong', 'status' => 400);
            }
        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    
        echo json_encode($response);
    }

	
	public function fetchbookmarkdetail() {
    	$res = $this->auth->decode_jwt_token();
    	if(!empty($res)) {
        	$request = json_decode(file_get_contents('php://input'),1); 
        	if(!empty($request['bookmark_id'])) {  
            	$book = $this->api_model->list_common_where3('bookmark','id', $request['bookmark_id']);
            	$datas['title']  = $book[0]['title'];
             	$datas['web_url'] = $book[0]['web_url'];
             	$datas['description'] = $book[0]['description'];
             	$response = array('error' => 'bookmark Details Found', 'status' => 200, 'data' => $datas);
        	
            }else{
               $response = array('error' => 'Please bookmark', 'status' => 400);
            }
        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    
        
    	echo json_encode($response);               
    }





} 

?>