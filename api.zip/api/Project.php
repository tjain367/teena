<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Project extends CI_Controller {

    function __construct() {
        parent::__construct();
        
        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: *");
        header("Access-Control-Allow-Headers: *");

        if ( "OPTIONS" === $_SERVER['REQUEST_METHOD'] ) {
            die();
        }        
    }


    public function fetchnature() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {
            $data = $this->api_model->listdata('nature');
            $response = array('success' => 'Show all nature', 'status' => 200, 'data' => $data);
        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }

    	echo json_encode($response);
    }


    public function fetchprojectsbyuser() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

        	$request = json_decode(file_get_contents('php://input'),1); 
            $response = array();

            if(!empty($request['user_id'])) {
            	$datas = array();
            
            	$nature = $this->api_model->listdata('nature');
            	
            	if(!empty($nature)) {
                	foreach($nature as $value) {
                    	$pro = $this->api_model->user_projects($request['user_id'], $value['id']);
                    	$prodat = array();	
                    
                    	if(!empty($pro)) {
                        	foreach($pro as $val) {
                        		array_push($prodat, array('id' => $val['id'], 'project_name' => $val['project_name']));
                            }
                        
                        	array_push($datas, array('id' => $value['id'], 'nature' => $value['nature'], 'projects' => $prodat));
                        }
                    }
                }
                
            	$response = array('error' => 'Success', 'status' => 200, 'data' => $datas);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }




    public function fetchusersbyproject() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 
            $response = array();

            if(!empty($request['project_id'])) {
                $datas = array();
				$listdat = $this->admin_model->list_common_where3('folder_list','id',$request['list_id']);
                $pro = $this->api_model->userbyprojects($request['project_id'], $request['user_id']);   

                foreach($pro as $val) {
                	$user = $this->admin_model->list_common_where3('users','id',$val['id']);
                    	
                    if(!empty($listdat[0]['assigned_to'])) {
                        $assigned = explode(",",$listdat[0]['assigned_to']);

                        if(in_array($val['id'], $assigned)) {
                            array_push($datas, array('id' => $user[0]['id'], 'name' => $user[0]['name'], 'assigned' => '1'));
                        }else{
                            array_push($datas, array('id' => $user[0]['id'], 'name' => $user[0]['name'], 'assigned' => '0'));
                        }
                    
                    	$datass['assigned'] = $listdat[0]['assigned_to'];
                    }else{
                        array_push($datas, array('id' => $user[0]['id'], 'name' => $user[0]['name'], 'assigned' => '0'));
                    	$datass['assigned'] = "";
                    }	
                }
            
            	$datass['users'] = $datas;
                
                $response = array('error' => 'Success', 'status' => 200, 'data' => $datass);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }


}

?>    