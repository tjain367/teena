<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Folder extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->config->load("jwt");

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: *");
        header("Access-Control-Allow-Headers: *");

        if ( "OPTIONS" === $_SERVER['REQUEST_METHOD'] ) {
            die();
        }
    }


    public function createfolder() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['user_id']) && !empty($request['folder_name'])) {

                $details['created_by']  = $request['user_id'];

                if(!empty($request['project_id'])) {
                    $details['project_id']  = $request['project_id'];
                }
                    
                $details['user_id']     = $request['user_id'];
                $details['folder_name'] = $request['folder_name'];
                $details['assigned_to'] = $request['user_id'];

                $result = $this->api_model->insert_common('generic_folder',$details);
                
                $response = array('error' => 'Folder added successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }


	
	public function createlist() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['user_id']) && !empty($request['list_name'])) {

                $details['created_by']  = $request['user_id'];
            
            	if(!empty($request['folder_id'])) {
                	$details['folder_id']   = $request['folder_id'];	
                }

                if(!empty($request['project_id'])) {
                    $details['project_id']  = $request['project_id'];
                }

                $details['list_name']   = $request['list_name'];
            	$details['assigned_to'] = $request['user_id'];

                $result = $this->api_model->insert_common('folder_list',$details);
                
                $response = array('error' => 'List added successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



	public function editlistname() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['list_id'])) {

                $details['list_name']   = $request['list_name'];

                $result = $this->api_model->update_common('folder_list',$details, 'id', $request['list_id']);
                
                $response = array('error' => 'List updated successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }
        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }

    
    
    
    
    public function fetchfolder() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 
            $datas = array();

            if(!empty($request['user_id'])) {
				
                if(!empty($request['project_id'])) {
                    $fold = $this->api_model->fetchfolder($request['user_id'], $request['project_id']);
                }else{
                    $fold = $this->api_model->fetchfolder($request['user_id'], '0');
                }    

                if(!empty($fold)) {
                    foreach($fold as $value) {
                    
                    	$list = $this->api_model->list_common_where3('folder_list','folder_id',$value['id']);
						
                        if(!empty($list)) {
                        	$listvalue = array();
                            foreach($list as $listval) {
                                $assigned_to = explode(",",$listval['assigned_to']);
                            	
                                if(in_array($request['user_id'], $assigned_to)) {
                                	$listvalue[] = $listval;
                                }                            
                            }    
                        	
                        	if(!empty($listvalue)) {
                                array_push($datas, array('id' => $value['id'], 'folder_name' => $value['folder_name'], 'list' => $listvalue));
                            }
                        }else{
                            if($request['user_id'] == $value['created_by']) {
                                array_push($datas, array('id' => $value['id'], 'folder_name' => $value['folder_name'], 'list' => $list));
                            }    
                        }    
                    }
                }    
                
           	 	$seperatelist = array();
                $seplist = $this->api_model->fetchseperatelist($request['project_id']);
						
                if(!empty($seplist)) {
                    foreach($seplist as $listval) {
                        $assigned_to = explode(",",$listval['assigned_to']);

                        if(in_array($request['user_id'], $assigned_to)) {
                            $seperatelist[] = $listval;
                        }                    
                    }
                }
            
            	$datass['folders'] = $datas;
            	$datass['seperatelist'] = $seperatelist;
            
                $response = array('error' => 'Folder found', 'status' => 200, 'data' => $datass);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }
    
    
    

    public function sharelisttouser() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['list_id']) && !empty($request['user_id'])) {
                
                $data['assigned_to'] = $request['user_id'].",".$request['assigned_to'];
                
                $this->api_model->update_common('folder_list',$data,'id',$request['list_id']);
                $response = array('error' => 'List Shared', 'status' => 200);
                
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



	public function list_shared_with() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['list_id'])) {
            	
            	$taskdat = $this->admin_model->list_common_where3('tasks','id',$request['task_id']);
            
            	$listdat = $this->admin_model->list_common_where3('folder_list','id',$request['list_id']);
            	
            	if(!empty($listdat[0]['assigned_to'])) {
                	$dataarr = array();
                	$assign = explode(",",$listdat[0]['assigned_to']);
                
                	foreach($assign as $value) {
                    	$user = $this->admin_model->list_common_where3('users','id',$value);
                    	
                    	if(!empty($taskdat[0]['assigned_to'])) {
                        	
                        	$assigned = explode(",",$taskdat[0]['assigned_to']);
                        
                        	if(in_array($value, $assigned)) {
                            	array_push($dataarr, array('id' => $user[0]['id'], 'name' => $user[0]['name'], 'assigned' => '1'));
                            }else{
                            	array_push($dataarr, array('id' => $user[0]['id'], 'name' => $user[0]['name'], 'assigned' => '0'));
                            }
                        
                        }else{
                        	array_push($dataarr, array('id' => $user[0]['id'], 'name' => $user[0]['name'], 'assigned' => '0'));
                        }
                    		
                    }
                
                	$response = array('error' => 'List Shared', 'status' => 200, 'data' => $dataarr);
                
                }else{
                	$response = array('error' => 'List Not Shared', 'status' => 200);
                }                
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



	

    public function updatefolder() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['folder_id'])) {
                
                $data['folder_name'] = $request['folder_name'];
                $result = $this->api_model->update_common('generic_folder',$data , 'id', $request['folder_id']);

                if($result) {
                    $response = array('error' => 'Folder Updated', 'status' => 200);
                }else{
                    $response = array('error' => 'Something went wrong', 'status' => 400);
                }
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }
        }else{
            $response = array('error' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }




    public function updatelist() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['list_id'])) {
                
                $data['list_name'] = $request['list_name'];
                $result = $this->api_model->update_common('folder_list',$data , 'id', $request['list_id']);

                if($result) {
                    $response = array('error' => 'List Updated', 'status' => 200);
                }else{
                    $response = array('error' => 'Something went wrong', 'status' => 400);
                }
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }
        }else{
            $response = array('error' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



    public function deletelist() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['list_id'])) {
                
                $data['flag'] = 1;
                $result = $this->api_model->update_common('folder_list',$data , 'id', $request['list_id']);

                if($result) {
                    $response = array('error' => 'List Deleted', 'status' => 200);
                }else{
                    $response = array('error' => 'Something went wrong', 'status' => 400);
                }
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }
        }else{
            $response = array('error' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }




    public function deletefolder() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['folder_id'])) {
                
                $data['flag'] = 1;
                $result = $this->api_model->update_common('generic_folder',$data , 'id', $request['folder_id']);

                if($result) {
                    $response = array('error' => 'Folder Deleted', 'status' => 200);
                }else{
                    $response = array('error' => 'Something went wrong', 'status' => 400);
                }
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }
        }else{
            $response = array('error' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }

    
}

?>    