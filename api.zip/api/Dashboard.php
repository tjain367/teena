<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->config->load("jwt");

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: *");
        header("Access-Control-Allow-Headers: *");

        if ( "OPTIONS" === $_SERVER['REQUEST_METHOD'] ) {
            die();
        }
    }


	public function tasks() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            $datas = $tasks_arr = $completed_tasks_arr = array();

            if(!empty($request['project_id'])) {
                $tasks = $this->dashboard_model->fetchprojecttask($request['user_id'], $request['project_id']);
            }else{
                $tasks = $this->dashboard_model->fetchtask($request['user_id']);
            }    

            if(!empty($tasks)) {
                foreach($tasks as $value) {
                    $project_id = $project_name = "";

                    if($value['list_id'] == 0) {
                        $label = "Tasks";
                    }else{
                        $lab = $this->dashboard_model->list_common_where3('folder_list','id', $value['list_id']);
                        if(!empty($lab[0]['list_name'])) {
                            $label = $lab[0]['list_name'];
                        
                            $fold = $this->dashboard_model->list_common_where3('generic_folder','id', $lab[0]['folder_id']);
                            if(!empty($fold[0]['folder_name'])) {
                                $label = $fold[0]['folder_name']." >> ".$label;
                            }
                        }
                    }

                    if(!empty($value['project_id'])) {
                        $project_id = $value['project_id'];
                        $project_name = $value['project_name'];
                    }

                    array_push($tasks_arr, array('id' => $value['id'], 'project_id' => $project_id, 'project_name' => $project_name, 'task' => $value['task'], 'label' => $label, 'created_at' => date_format(date_create($value['created_at']),"d M, Y") ));
                }
            }       

            $datas = $tasks_arr;

            $response = array('error' => 'Task found', 'status' => 200, 'data' => $datas);
        

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }






    // fetch all today tasks by project
    public function notes() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 
            $datas = $tasks_arr = array();

            if(!empty($request['project_id'])) {
                $book = $this->dashboard_model->list_notesexceptproject_id('notes', $request['user_id'], $request['project_id']);
            }else{
                $book = $this->dashboard_model->fetch_notes_created_by($request['user_id']);
            }

            if(!empty($book)) {
                foreach($book as $value) {
                    $project_id = $project_name = "";

                    if(!empty($value['project_id'])) {
                        $project_id = $value['project_id'];
                        $project_name = $value['project_name'];
                    }

                    array_push($datas, array('id' => $value['id'], 'project_id' => $project_id, 'project_name' => $project_name, 'date' => $value['date'], 'time' => $value['time'], 'title' => $value['title'], 'description' => $value['description'], 'created_at' => $value['created_at']));
                }
            }    

            $response = array('error' => 'Meeting found', 'status' => 200, 'data' => $datas);

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }


}
?>