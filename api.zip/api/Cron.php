<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Cron extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->config->load("jwt");

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: *");
        header("Access-Control-Allow-Headers: *");

        if ( "OPTIONS" === $_SERVER['REQUEST_METHOD'] ) {
            die();
        }
    }


    public function index() {
        $this->fetchnotificationfortask();
    }


    public function fetchnotificationfortask() {

        date_default_timezone_set('Asia/kolkata');
        $today_date = date('Y-m-d H:i');

        $reminder = $this->api_model->list_task_reminder($today_date);
        if(!empty($reminder)) {
            foreach($reminder as $value) {
                
                $data['user_id']     = $value['user_id'];
                $data['project_id']  = $value['project_id'];
                $data['description'] = "Remainder at : ".$value['task'];
                
                $this->api_model->insert_common('task_notification',$data);
            }
        }
    

    }


}

?>    