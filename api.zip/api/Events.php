<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Events extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->config->load("jwt");

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: *");
        header("Access-Control-Allow-Headers: *");

        if ( "OPTIONS" === $_SERVER['REQUEST_METHOD'] ) {
            die();
        }
    }
    public function create() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['user_id']) && !empty($request['event_name']) && !empty($request['project_id'])) {
                date_default_timezone_set('Asia/kolkata');
                $details['event_name'] = $request['event_name'];
                $details['project_id']  = $request['project_id'];
                $details['start_date'] = $request['start_date'];
                $details['end_date'] = $request['end_date'];
                $details['location'] = $request['location'];
                $details['description'] = $request['description'];
                $result = $this->api_model->insert_common('events',$details);
                
                $response = array('error' => 'Event added successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }
    
}