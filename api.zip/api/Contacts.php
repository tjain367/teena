<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Contacts extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->config->load("jwt");

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: *");
        header("Access-Control-Allow-Headers: *");

        if ( "OPTIONS" === $_SERVER['REQUEST_METHOD'] ) {
            die();
        }
    }


    public function create() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['user_id'])) {

                date_default_timezone_set('Asia/kolkata');            

                $details['created_by']      = $request['user_id'];
                $details['project_id']      = $request['project_id'];
                $details['company_name']    = $request['comname'];
                $details['first_name']      = $request['firstname'];  
                $details['last_name']       = $request['lastname'];  
                $details['department']      = $request['department'];  
                $details['notes']           = $request['notes'];  
                $details['role']            = 'vendor';  

                if(!empty($request['comname'])){
                    $words = explode(" ", $request['comname']);
                    $acronym = "";

                    foreach ($words as $w) {
                      $acronym .= $w[0];
                    }

                    $details['initial'] = strtoupper($acronym);
                }    

                $result = $this->api_model->insert_common('contacts',$details);

                $email = $request['emailArray'];
                if(!empty($email)) {
                    for($i = 0; $i < count($email); $i++) {
                        $dataa = array('contact_id' => $result, 'email' => $email[$i]['email']);
                        $this->api_model->insert_common('contact_email',$dataa); 
                    }

                    $savedata['email'] = $email[0]['email'];
                	$this->api_model->update_common('contacts',$savedata,'id',$result);
                }

                $phone = $request['phonearray'];

                if(!empty($phone)) {
                    for($i = 0; $i < count($phone); $i++) {
                        $dataa2 = array('contact_id' => $result, 'phone' => $phone[$i]['phone'], 'work' => $phone[$i]['mobile']);
                        $this->api_model->insert_common('contact_phone',$dataa2); 
                    }

                    $savedata['phone'] = $phone[0]['phone'];
                	$this->api_model->update_common('contacts',$savedata,'id',$result);
                }

                $category = $request['category'];
                if(!empty($category)) {
                    for($i = 0; $i < count($category); $i++) {
                        $dataa = array('contact_id' => $result, 'category' => $category[$i]);
                        $this->api_model->insert_common('contact_category',$dataa); 
                    }
                }
            
            	if(!empty($request['project_id'])) {
                	$prodat['project_id'] = $request['project_id'];
                	$prodat['contact_id'] = $result;
                	$prodat['added_by'] = $request['user_id'];
                	$this->api_model->insert_common('contact_projects',$prodat); 
                }

                $response = array('error' => 'Contact saved successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }




    public function update() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['contact_id'])) {

                date_default_timezone_set('Asia/kolkata');            

                $details['company_name']    = $request['company_name'];
                $details['first_name']      = $request['first_name'];  
                $details['last_name']       = $request['last_name'];  
                $details['department']      = $request['department'];  
                $details['notes']           = $request['notes'];  

                $contact_id = $request['contact_id'];

                if(!empty($request['company_name'])){
                    $words = explode(" ", $request['company_name']);
                    $acronym = "";

                    foreach ($words as $w) {
                      $acronym .= $w[0];
                    }

                    $details['initial'] = strtoupper($acronym);
                }    

                $this->api_model->update_common('contacts',$details, 'id', $contact_id);


                $email = $request['emailArray'];
                if(!empty($email)) {
                    $this->api_model->delete_common('contact_email','contact_id',$contact_id);

                    for($i = 0; $i < count($email); $i++) {
                        $dataa = array('contact_id' => $contact_id, 'email' => $email[$i]['email']);
                        $this->api_model->insert_common('contact_email',$dataa); 
                    }

                    $savedata['email'] = $email[0]['email'];
                    $this->api_model->update_common('contacts',$savedata,'id',$contact_id);
                }


                $phone = $request['phonearray'];

                if(!empty($phone)) {
                    $this->api_model->delete_common('contact_phone','contact_id',$contact_id);

                    for($i = 0; $i < count($phone); $i++) {
                        $dataa2 = array('contact_id' => $contact_id, 'phone' => $phone[$i]['phone'], 'work' => $phone[$i]['mobile']);
                        $this->api_model->insert_common('contact_phone',$dataa2); 
                    }

                    $savedata['phone'] = $phone[0]['phone'];
                    $this->api_model->update_common('contacts',$savedata,'id',$contact_id);
                }

                $category = $request['category'];
                if(!empty($category)) {
                    $this->api_model->delete_common('contact_category','contact_id',$contact_id);

                    for($i = 0; $i < count($category); $i++) {
                        $dataa = array('contact_id' => $contact_id, 'category' => $category[$i]);
                        $this->api_model->insert_common('contact_category',$dataa); 
                    }
                }

                $response = array('error' => 'Contact updated successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }




    public function createinhouse() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['user_id']) && !empty($request['project_id'])) {

                date_default_timezone_set('Asia/kolkata');

                $details['created_by']      = $request['user_id'];
                $details['project_id']      = $request['project_id'];
                $details['first_name']      = $request['first_name'];  
                $details['last_name']       = $request['last_name'];  
                $details['role']            = "inhouse";

                $data['initial'] = 'DDEPL';
                $result = $this->api_model->insert_common('contacts',$details);

                $email = $this->input->post('email');
                if(!empty($email)) {
                    for($i = 0; $i < count($email); $i++) {
                        $dataa = array('contact_id' => $saved, 'email' => $email[$i]);
                        $this->api_model->insert_common('contact_email',$dataa); 
                    }
                }

                $phone = $this->input->post('phone');
                $work  = $this->input->post('work');

                if(!empty($phone)) {
                    for($i = 0; $i < count($phone); $i++) {
                        $dataa2 = array('contact_id' => $saved, 'phone' => $phone[$i], 'work' => $work[$i]);
                        $this->api_model->insert_common('contact_email',$dataa2); 
                    }

                    $savedata['phone'] = $phone[0];
                }
                
                $response = array('error' => 'Contact saved successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }
    


    public function fetchall() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {
        
        	$request = json_decode(file_get_contents('php://input'),1); 

            $datas = array();
        
        	if(!empty($request['project_id'])) {
            	$book = $this->api_model->contactprojectwise($request['project_id']);
            }else{
            	$book = $this->api_model->listcontact('contacts');
            }

            if(!empty($book)) {
                foreach($book as $value) {
                    array_push($datas, array('id' => $value['id'], 'initial' => $value['initial'], 'first_name' => $value['first_name'], 'email' => $value['email'], 'phone' => $value['phone'], 'last_name' => $value['last_name']));
                }
            }    

            $response = array('error' => 'Contacts found', 'status' => 200, 'data' => $datas);
        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



	public function fetchallindustry() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1);
            $datas = array();

            if($request['project_id']) {
                $book = $this->api_model->listindustry2($request['project_id']);
            }else{
                $book = $this->api_model->listindustry();
            }

            if(!empty($book)) {
                foreach($book as $value) {
                    array_push($datas, array('id' => $value['id'], 'type' => $value['type']));
                }
            }    

            $response = array('error' => 'Industry found', 'status' => 200, 'data' => $datas);
        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



    public function fetchcontactdetails() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $datas = $email = $phone = $category = array();

            $request = json_decode(file_get_contents('php://input'),1); 

            $book = $this->api_model->list_common_where3('contacts','id',$request['contact_id']);

            if(!empty($book)) {
                $datas['email']        = "";
                $datas['phone']        = "";
                $datas['id']           = $book[0]['id'];
                $datas['initial']      = $book[0]['initial'];
                $datas['first_name']   = $book[0]['first_name'];
                $datas['last_name']    = $book[0]['last_name'];
                $datas['department']   = $book[0]['department'];
                $datas['notes']        = $book[0]['notes'];
                $datas['company_name'] = $book[0]['company_name'];

                $emails = $this->api_model->list_common_where3('contact_email','contact_id',$request['contact_id']);
                if(!empty($emails)) {
                    foreach($emails as $value) {
                        array_push($email, array('email' => $value['email']));
                    }
                }    

                $phones = $this->api_model->list_common_where3('contact_phone','contact_id',$request['contact_id']);
                if(!empty($phones)) {
                    foreach($phones as $value) {
                        array_push($phone, array('phone' => $value['phone'], 'work' => $value['work']));
                    }
                }

                $categorys = $this->api_model->list_common_where3('contact_category','contact_id',$request['contact_id']);
                if(!empty($categorys)) {
                    foreach($categorys as $value) {
                        array_push($category, array('category' => $value['category']));
                    }
                }

                $datas['email'] = $email;
                $datas['phone'] = $phone;
                $datas['category'] = $category;
            }    

            $response = array('error' => 'Contacts found', 'status' => 200, 'data' => $datas);

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



	public function orderwise() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {  
            $datas = array();
            $request = json_decode(file_get_contents('php://input'),1); 
            $book = $this->api_model->getcontactorderwise($request['project_id'],$request['category_name'],$request['order']);
            if(!empty($book)) {
                foreach($book as $value) {
                    array_push($datas, array('id' => $value['id'], 'initial' => $value['initial'],  'first_name' => $value['first_name'], 'email' => $value['email'], 'phone' => $value['phone'], 'last_name' => $value['last_name']));
                }
            }
            $response = array('error' => 'descending found', 'status' => 200, 'data' =>$datas);
        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    
        echo json_encode($response);
    }

    
    
    public function filterbycategory() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {  
            $datas = array();
            $request = json_decode(file_get_contents('php://input'),1); 
        
        	if(!empty($request['category_name'])) {
            	if(!empty($request['project_id'])) {
                	$book = $this->api_model->categoryfilterprojectwise($request['project_id'], $request['category_name']);
                }else{
                	$book = $this->api_model->categoryfilter($request['category_name']);
                }
            
            	if(!empty($book)) {
	                foreach($book as $value) {
    	                array_push($datas, array('id' => $value['id'], 'initial' => $value['initial'], 'first_name' => $value['first_name'], 'email' => $value['email'], 'phone' => $value['phone'], 'last_name' => $value['last_name']));
	                }
    	        }
            
            	$response = array('error' => 'Data found', 'status' => 200, 'data' =>$datas);
            }else{
            	$response = array('error' => 'Invalid Request', 'status' => 400);
            }
        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    
        echo json_encode($response);
    }



	public function addcontacttoprojects() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {  
            $datas = array();
            $request = json_decode(file_get_contents('php://input'),1); 
        
        	if(!empty($request['assigned_to']) && !empty($request['project_id'])) {
            
            	$data['added_by'] = $request['user_id'];
            	$data['project_id'] = $request['project_id'];
            	
            	$assign = explode(",",$request['assigned_to']);
            	for($i = 0; $i < count($assign); $i++) {
            		 $data['contact_id'] = $assign[$i];
                	 $saved = $this->api_model->insert_common('contact_projects',$data);
                }
            
            	if($saved) {
                	$response = array('error' => 'Contacts Added to Project', 'status' => 200);
                }else{
                	$response = array('error' => 'Something went wrong! Try Again', 'status' => 400);
                }
            }else{
            	$response = array('error' => 'Invalid Request', 'status' => 400);
            }
        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    
        echo json_encode($response);
    }




	public function list_shared_with() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 
            $dataarr = array();

            if(!empty($request['project_id'])) {
            	
            	$taskdat = $this->api_model->listdata('contacts');
            
            	$listdat = $this->api_model->contactprojectwise($request['project_id']);
            
            	if(!empty($listdat)) {
                	$last_names = array_column($listdat, 'id');
                
                	foreach($taskdat as $value) {
                    	
                        if(in_array($value['id'], $last_names)) {
                        	array_push($dataarr, array('id' => $value['id'], 'initial' => $value['initial'], 'first_name' => $value['first_name'], 'email' => $value['email'], 'phone' => $value['phone'], 'last_name' => $value['last_name'], 'assigned' => '1'));
                        }else{
                        	array_push($dataarr, array('id' => $value['id'], 'initial' => $value['initial'], 'first_name' => $value['first_name'], 'email' => $value['email'], 'phone' => $value['phone'], 'last_name' => $value['last_name'], 'assigned' => '0'));
                        }
                    }
                
                }else{
                    foreach($taskdat as $value) {        
                        array_push($dataarr, array('id' => $value['id'], 'initial' => $value['initial'], 'first_name' => $value['first_name'], 'email' => $value['email'], 'phone' => $value['phone'], 'last_name' => $value['last_name'], 'assigned' => '0'));
                    }
                }                

                $response = array('error' => 'List Shared', 'status' => 200, 'data' => $dataarr);

            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }





    public function delete() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['contact_id'])) {

                if(!empty($request['project_id'])) {
                    $book = $this->api_model->delete_common_contact($request['contact_id'], $request['project_id']);
                }else{
                    $book = $this->api_model->delete_common('contacts', 'id', $request['contact_id']);
                }

                $response = array('error' => 'Contact deleted Successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Please Select Contact', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }




    public function getindustryofcontact() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 
            $data = array();

            if(!empty($request['contact_id'])) {

                $book = $this->api_model->list_common_where3('contact_category', 'contact_id', $request['contact_id']);

                if(!empty($book)) {
                    foreach($book as $value) {
                        array_push($data, array('item_text' => $value['category']));
                    }
                }

                $response = array('error' => 'Contact Category Found', 'status' => 200, 'industry' => $data);
            }else{
                $response = array('error' => 'Please Select Contact', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }


    
} 

?>