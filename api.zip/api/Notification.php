<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Notification extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->config->load("jwt");

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: *");
        header("Access-Control-Allow-Headers: *");

        if ( "OPTIONS" === $_SERVER['REQUEST_METHOD'] ) {
            die();
        }
    }


    public function list() {
        
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['user_id'])) {
                $datas = $tasks_arr = array();

                $book = $this->api_model->list_common_where3('task_notification', 'user_id', $request['user_id']);

                if(!empty($book)) {
                    foreach($book as $value) {
                        array_push($datas, array('project_id' => $value['project_id'], 'description' => $value['description'], 'created_at' => $value['timestamp']));
                    }
                }    

                $response = array('error' => 'Notification found', 'status' => 200, 'data' => $datas);
            }else{
                $response = array('error' => 'Please Select Project', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);

    }


}

?>    