<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Notes extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->config->load("jwt");

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: *");
        header("Access-Control-Allow-Headers: *");

        if ( "OPTIONS" === $_SERVER['REQUEST_METHOD'] ) {
            die();
        }
    }


    public function create() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['user_id']) && !empty($request['title'])) {

                date_default_timezone_set('Asia/kolkata');

                $details['created_by']  = $request['user_id'];

                if(!empty($request['project_id'])) {
                    $details['project_id']  = $request['project_id'];    
                }
                
                $details['title']       = $request['title'];
                $details['description'] = $request['description'];  
            	$details['date'] 		= $request['date'];
            	$details['time'] 		= $request['time'];

                if(!empty($request['folder_id'])) {
                    $details['folder_id'] = $request['folder_id'];
                }

                $result = $this->api_model->insert_common('notes',$details);
                
                $response = array('error' => 'Meeting added successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



    // fetch all today tasks by project
    public function fetchall() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 
            $datas = $tasks_arr = array();

            if(!empty($request['project_id'])) {

                if($request['folder_id'] == '0') {
                    $book = $this->api_model->list_notesexceptproject_id('notes', $request['user_id'], $request['project_id']);
                }else{
                    $book = $this->api_model->fetch_notes_folder($request['folder_id']);
                }

            }else{

                $datas = $tasks_arr = array();

                if($request['folder_id'] == '0') {
                    $book = $this->api_model->fetch_notes_created_by($request['user_id']);
                }else{
                    $book = $this->api_model->fetch_notes_folder($request['folder_id']);
                }
            }

            if(!empty($book)) {
                foreach($book as $value) {
                    $project_id = $project_name = "";

                    if(!empty($value['project_id'])) {
                        $project_id = $value['project_id'];
                        $project_name = $value['project_name'];
                    }

                    array_push($datas, array('id' => $value['id'], 'project_id' => $project_id, 'project_name' => $project_name, 'date' => $value['date'], 'time' => $value['time'], 'title' => $value['title'], 'description' => $value['description'], 'created_at' => $value['created_at']));
                }
            }    

            $response = array('error' => 'Meeting found', 'status' => 200, 'data' => $datas);

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }







	public function fetchnotesdetail() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['notes_id'])) {                

                $book = $this->api_model->list_common_where3('notes', 'id', $request['notes_id']);
				
            	$datas['title'] 	  = $book[0]['title'];
            	$datas['description'] = $book[0]['description'];
            	$datas['created_at']  = $book[0]['created_at'];
            	$datas['date'] 		  = $book[0]['date'];
            	$datas['time'] 		  = $book[0]['time'];
            
                $response = array('error' => 'Meeting Details Found', 'status' => 200, 'data' => $datas);
            }else{
                $response = array('error' => 'Please Meeting', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



    public function delete() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['notes_id'])) {

                $book = $this->api_model->delete_common('notes', 'id', $request['notes_id']);

                $response = array('error' => 'Meeting deleted Successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Please Select Meeting', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



	public function update() {
        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {
            $request = json_decode(file_get_contents('php://input'),1); 
            if(!empty($request['notes_id'])) {
            
                $datas = array(
                    'id' => $request['notes_id'],
                    'title' => $request['title'],
                    'description' => $request['description'],
                	'date'		 => $request['date'],
                	'time'		=> $request['time']
                   );
             
                $book = $this->api_model->update_common('notes', $datas,'id',$request['notes_id']);
                $response = array('error' => 'Meeting update Successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Something Went Wrong', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    
    
        echo json_encode($response);
    }


	
	public function datewise() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['project_id'])) {
                $datas = $tasks_arr = array();

                if($request['folder_id'] == '0') {
                    $book = $this->api_model->list_notesexceptproject_id_datewise('notes', $request['user_id'], $request['project_id'], $request['fromdate'], $request['todate']);
                }else{
                    $book = $this->api_model->list_common_where3_datewise('notes', 'folder_id', $request['folder_id'], $request['fromdate'], $request['todate']);
                }

                if(!empty($book)) {
                    foreach($book as $value) {
                        array_push($datas, array('id' => $value['id'], 'title' => $value['title'], 'date' => $value['date'], 'time' => $value['time'], 'description' => $value['description'], 'created_at' => $value['created_at']));
                    }
                }    

                $response = array('error' => 'Meeting found', 'status' => 200, 'data' => $datas);
            }else{
                $response = array('error' => 'Please Select Project', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }
	



} 

?>