<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Authorization extends CI_Controller {

    function __construct() {
        parent::__construct();

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
        header("Access-Control-Allow-Headers: *");

		if ( "OPTIONS" === $_SERVER['REQUEST_METHOD'] ) {
		    die();
		}

        $this->load->library('email');
    }


    public function register() {
        $request = json_decode(file_get_contents('php://input'),1); 
        $response = array();

        if(!empty($request['email'])) {
            if($request['confirm_password'] == $request['password']) {

                if(empty($this->api_model->userexist($request['email']))) {

                    $details['user_type'] = '2';
                    $details['name']      = $request['name'];
                    $details['email']     = $request['email'];
                    $details['role']      = 'user';
                    $details['flag']      = '1';
                    $details['password']  = $this->enc_lib->passHashEnc($request['password']);

                    $result = $this->api_model->insert_common('users',$details);

                    if(!empty($result)) {
                        $response = array('success' => 'You have successfully Registered. you can access your account when admin will approve', 'status' => 200);
                    }else{
                        $response = array('error' => 'Something went Wrong! Try Again', 'status' => 400);    
                    }
                }else{
                    $response = array('error' => 'Email Address already Exist', 'status' => 400);
                }
            }else{
                $response = array('error' => 'Password and Confirm password must be same!', 'status' => 400);
            }
        }else{
            $response = array('error' => 'Invalid Request', 'status' => 400);
        }

        echo json_encode($response);
        exit;
    }




    public function login() {
        $request = json_decode(file_get_contents('php://input'),1); 

        $response = array();

        if(!empty($request['email']) && !empty($request['password'])) {

            if(!empty($user = $this->api_model->getByEmail($request['email']))) {

                $login_post = array(
                    'email'    => $request['email'],
                    'password' => $request['password']
                );

                $data = $this->api_model->checkLogin($login_post);

                if(!empty($data)) {
                    if($data->flag == 0) {

                        $token = $this->jwt_token($data);
                        $response = array('success' => 'You have successfully login', 'status' => 200,'token' => $token,'data' => $user);
                    
                    }else{
                        $response = array('error' => 'Your account is temporary blocked, Please contct to admin team.', 'status' => 400);
                    }
                }else{
                    $response = array('error' => 'Wrong Password', 'status' => 400);    
                }
            }else{
                $response = array('error' => 'Email Address not Exist', 'status' => 400);
            }
        }else{
            $response = array('error' => 'Invalid Request', 'status' => 400);
        }

        echo json_encode($response);
    }




    public function jwt_token($data) {
        $jwt = new JWT();
        $jwtSecretKey = $this->config->item('jwt_key');

        $token = $jwt->encode($data,$jwtSecretKey,'HS256');
        return $token;
    }




    public function forget_password() {

        $request = json_decode(file_get_contents('php://input'),1); 
        $response = array();

        if(!empty($request['email'])) {
            if(!empty($this->api_model->userexist($request['email']))) {

                $config = Array(
                    'protocol' => 'mail',
                    'smtp_host' => 'smtp.gmail.com',
                    'smtp_port' => 587, 
                    'smtp_user' => 'vikrant11933@gmail.com',
                    'smtp_pass' => 'pakistankebaaphum',
                    'newline' => '\r\n',
                    'mailtype' => 'html',
                    'charset' => 'utf-8',
                    'wordwrap' => TRUE
                );

                $otp = rand(100000,999999);
                $subject = "Change Password Request";
                $message = $otp. " is your otp for change your password in Project Management System";
                        
                $headers = 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

                $this->email->initialize($config);
                $this->email->from('vikrant11933@gmail.com');
                $this->email->to($request['email']);
                $this->email->subject($subject);
                $this->email->message($message);
                $this->email->send();

                $details['otp']  = $otp;
                $result = $this->api_model->update_common('users', $details, 'email', $request['email']);

                $response = array('error' => 'Check your Mail for Reset Password', 'status' => 200);

            }else{
                $response = array('error' => 'Email Address is not registered', 'status' => 400);
            }
        }else{
            $response = array('error' => 'Invalid Request', 'status' => 400);
        }

        echo json_encode($response);
        exit;
    }




    public function verify_otp() {

        $request = json_decode(file_get_contents('php://input'),1); 
        $response = array();

        if(!empty($request['email'])) {
            if(!empty($user = $this->api_model->list_common_where3('users', 'email', $request['email']))) {

                if($request['otp'] == $user[0]['otp']) {

                    $details['otp']  = "";
                    $result = $this->api_model->update_common('users', $details, 'email', $request['email']);

                    $response = array('success' => 'OTP Matched', 'status' => 200, 'otp' => 'matched');

                }else{
                    $response = array('error' => 'Invalid OTP', 'status' => 400);    
                }
            }else{
                $response = array('error' => 'Email Address is not registered', 'status' => 400);
            }
        }else{
            $response = array('error' => 'Invalid Request', 'status' => 400);
        }

        echo json_encode($response);
        exit;
    }



    public function change_password() {

        $request = json_decode(file_get_contents('php://input'),1); 
        $response = array();

        if(!empty($request['email'])) {
            if(!empty($this->api_model->userexist($request['email']))) {

                if($request['confirm_password'] == $request['password']) {

                    $details['password']  = $this->enc_lib->passHashEnc($request['password']);
                    $result = $this->api_model->update_common('users', $details, 'email', $request['email']);

                    if(!empty($result)) {
                        $response = array('success' => 'Password Updated Successfully', 'status' => 200);
                    }else{
                        $response = array('error' => 'Something went Wrong! Try Again', 'status' => 400);    
                    }

                }else{
                    $response = array('error' => 'Password & Confirm Password must be same', 'status' => 400);
                }
            }else{
                $response = array('error' => 'Email Address is not registered', 'status' => 400);
            }
        }else{
            $response = array('error' => 'Invalid Request', 'status' => 400);
        } 

        echo json_encode($response);
        exit;
    }

}

?>    