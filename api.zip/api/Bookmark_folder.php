<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Bookmark_folder extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->config->load("jwt");

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: *");
        header("Access-Control-Allow-Headers: *");

        if ( "OPTIONS" === $_SERVER['REQUEST_METHOD'] ) {
            die();
        }
    }


    public function createfolder() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['user_id']) && !empty($request['folder_name']) && !empty($request['project_id'])) {

                $details['created_by']  = $request['user_id'];
                $details['project_id']  = $request['project_id'];

                if(!empty($request['folder_id'])) {
                    $details['folder_id']     = $request['folder_id'];                    
                }

                $details['folder_name'] = $request['folder_name'];
                $details['assigned_to'] = $request['user_id'];

                $result = $this->api_model->insert_common('bookmark_folder',$details);
                
                $response = array('error' => 'Folder added successfully', 'status' => 200);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }

    
    
    
    
    public function fetchfolder() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1);             

            if(!empty($request['user_id']) && !empty($request['project_id'])) {

                $fold = $this->api_model->fetchnotesmainfolder($request['project_id'], 'bookmark_folder', '0');

                if(!empty($fold)) {
                    $folder =  array();
                    foreach($fold as $value) {
                    
                        $subfolders = $this->api_model->fetchnotesmainfolder($request['project_id'], 'bookmark_folder', $value['id']);

                        $subfolder = $subfold = array();
                        if(!empty($subfolders)) {
                            
                            foreach($subfolders as $subvalue) {

                                $subsubfolders = $this->api_model->fetchnotesmainfolder($request['project_id'], 'bookmark_folder', $subvalue['id']);
                            
                                $subsubfolder = $subsubfold = array();
                                if(!empty($subsubfolders))  {
                                    foreach($subsubfolders as $subsubvalue) {

                                        $assigned_to = explode(",",$subsubvalue['assigned_to']);

                                        if(in_array($request['user_id'], $assigned_to)) {                                        
                                            array_push($subsubfolder, array('id' => $subsubvalue['id'], 'folder_name' => $subsubvalue['folder_name']));
                                            $subsubfold[] = $subsubvalue['folder_id']; 
                                        }
                                    }
                                }

                                $assigned_to2 = explode(",",$subvalue['assigned_to']);

                                if(in_array($request['user_id'], $assigned_to2) || in_array($subvalue['id'], $subsubfold)) {
                                    array_push($subfolder, array('id' => $subvalue['id'], 'folder_name' => $subvalue['folder_name'], 'subsubfolder' => $subsubfolder));
                                    $subfold[] = $subvalue['folder_id']; 
                                }
                            }
                        }

                        $assigned_to3 = explode(",",$value['assigned_to']);

                        if(in_array($request['user_id'], $assigned_to3) || in_array($value['id'], $subfold)) {
                            array_push($folder, array('id' => $value['id'], 'folder_name' => $value['folder_name'], 'subfolder' => $subfolder));
                        }

                    }
                }    
            
                $response = array('error' => 'Folder found', 'status' => 200, 'data' => $folder);
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }
    
    
    

    public function sharefoldertouser() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['list_id']) && !empty($request['user_id'])) {
                
                $data['assigned_to'] = $request['user_id'].",".$request['assigned_to'];
                
                $this->api_model->update_common('bookmark_folder',$data,'id',$request['folder_id']);
                $response = array('error' => 'Folder Shared', 'status' => 200);
                
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



	public function list_shared_with() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['list_id'])) {
            	
            	$taskdat = $this->admin_model->list_common_where3('tasks','id',$request['task_id']);
            
            	$listdat = $this->admin_model->list_common_where3('folder_list','id',$request['list_id']);
            	
            	if(!empty($listdat[0]['assigned_to'])) {
                	$dataarr = array();
                	$assign = explode(",",$listdat[0]['assigned_to']);
                
                	foreach($assign as $value) {
                    	$user = $this->admin_model->list_common_where3('users','id',$value);
                    	
                    	if(!empty($taskdat[0]['assigned_to'])) {
                        	
                        	$assigned = explode(",",$taskdat[0]['assigned_to']);
                        
                        	if(in_array($value, $assigned)) {
                            	array_push($dataarr, array('id' => $user[0]['id'], 'name' => $user[0]['name'], 'assigned' => '1'));
                            }else{
                            	array_push($dataarr, array('id' => $user[0]['id'], 'name' => $user[0]['name'], 'assigned' => '0'));
                            }
                        
                        }else{
                        	array_push($dataarr, array('id' => $user[0]['id'], 'name' => $user[0]['name'], 'assigned' => '0'));
                        }
                    		
                    }
                
                	$response = array('error' => 'List Shared', 'status' => 200, 'data' => $dataarr);
                
                }else{
                	$response = array('error' => 'List Not Shared', 'status' => 200);
                }                
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }

        }else{
            $response = array('success' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }



	
    public function updatefolder() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['folder_id'])) {
                
                $data['folder_name'] = $request['folder_name'];
                $result = $this->api_model->update_common('bookmark_folder',$data , 'id', $request['folder_id']);

                if($result) {
                    $response = array('error' => 'Folder Updated', 'status' => 200);
                }else{
                    $response = array('error' => 'Something went wrong', 'status' => 400);
                }
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }
        }else{
            $response = array('error' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }
    



    public function deletefolder() {

        $res = $this->auth->decode_jwt_token();
        if(!empty($res)) {

            $request = json_decode(file_get_contents('php://input'),1); 

            if(!empty($request['folder_id'])) {
                
                $data['flag'] = 1;
                $result = $this->api_model->update_common('bookmark_folder',$data , 'id', $request['folder_id']);

                if($result) {
                    $response = array('error' => 'Folder Deleted', 'status' => 200);
                }else{
                    $response = array('error' => 'Something went wrong', 'status' => 400);
                }
            }else{
                $response = array('error' => 'Invalid Request', 'status' => 400);
            }
        }else{
            $response = array('error' => 'Invalid Token', 'status' => 400);
        }    

        echo json_encode($response);
    }

    

    
}

?>    